package com.example.runtimepermission.activities;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import com.example.runtimepermission.R;
import android.support.v4.content.ContextCompat;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.support.v4.app.ActivityCompat;
import java.util.ArrayList;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
	
	int storage,camera,audio;
	private static final int PERMISSION_REQUEST = 1;
	ArrayList<String> permisos = new ArrayList();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
		permisos();
		//UnSoloPermiso();
    }
	public void permisos(){
		if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP){
			storage = ContextCompat.checkSelfPermission(this,Manifest.permission.READ_EXTERNAL_STORAGE);
		    camera = ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA);
	        audio = ContextCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO);
			
			if(storage != PackageManager.PERMISSION_GRANTED){
				permisos.add(Manifest.permission.READ_EXTERNAL_STORAGE);
			}
			if(camera != PackageManager.PERMISSION_GRANTED){
				permisos.add(Manifest.permission.CAMERA);
			}
			if(audio != PackageManager.PERMISSION_GRANTED){
				permisos.add(Manifest.permission.RECORD_AUDIO);
			}
			if(!permisos.isEmpty()){
				ActivityCompat.requestPermissions(this,permisos.toArray(new String[permisos.size()]),PERMISSION_REQUEST);
				Toast.makeText(this,"Ejemplo De Permisos En Runtime Con Bucle Repetitivo",Toast.LENGTH_LONG).show();
			}
			
			}
			
	}

	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults)
	{
		// TODO: Implement this method
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if(requestCode == PERMISSION_REQUEST){
			if(grantResults[0] == PackageManager.PERMISSION_GRANTED){
				Toast.makeText(this,"Permisos Concedidos",Toast.LENGTH_LONG).show();
			}else{
				ActivityCompat.requestPermissions(this,permisos.toArray(new String[permisos.size()]),PERMISSION_REQUEST);
			}
		}
	}
	/**public void UnSoloPermiso(){
		if(ContextCompat.checkSelfPermission(this,Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED){
			ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},PERMISSION_REQUEST);
			
		}else{
			Toast.makeText(this,"Metodo Que Se Ejecuta Siempre Al Abrir La Activity",Toast.LENGTH_LONG).show();
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults)
	{
		// TODO: Implement this method
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if(requestCode == PERMISSION_REQUEST){
			if(grantResults[0] == PackageManager.PERMISSION_GRANTED){
				Toast.makeText(this,"Primera Ves Concedido El Permiso",Toast.LENGTH_LONG).show();
			}else{
				ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},PERMISSION_REQUEST);
			}
			}
			}**/
	
}
