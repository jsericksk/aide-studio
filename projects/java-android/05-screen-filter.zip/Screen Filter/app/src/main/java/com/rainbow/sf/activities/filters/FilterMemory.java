package com.rainbow.sf.activities.filters;
import android.content.SharedPreferences;
import android.content.Context;
import android.graphics.Color;

public class FilterMemory
{
	SharedPreferences sp;
	
	public FilterMemory(Context context){
		sp = context.getSharedPreferences("filters_screen",Context.MODE_PRIVATE);
		
	}
	private int getValue(String prop,int def){
		return sp.getInt(prop,def);
	}
	public int getAlpha(){
		return getValue("alpha",0x33);
	}
	public int getRed(){
		return getValue("red",0x00);
	}
	public int getGreen(){
		return getValue("green",0x00);
	}
	public int getBlue(){
		return getValue("blue",0x00);
	}
	private void setValue(String value,int v){
		sp.edit().putInt(value,v).apply();
	}
	public void setAlpha(int alpha){
		setValue("alpha",alpha);
	}
	public void setRed(int red){
		setValue("red",red);
	}
	public void setGreen(int green){
		setValue("green",green);
	}
	public void setBlue(int blue){
		setValue("blue",blue);
	}
	public int getColor(){
		return Color.argb(getAlpha(),getRed(),getGreen(),getBlue());
	}
	
}
