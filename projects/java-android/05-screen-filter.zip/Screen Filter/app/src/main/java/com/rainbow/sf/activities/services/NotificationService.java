package com.rainbow.sf.activities.services;
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.support.v7.app.NotificationCompat;
import android.app.Notification;
import java.nio.channels.NotYetBoundException;
import android.app.NotificationManager;

import com.rainbow.sf.R;
import android.app.PendingIntent;
import com.rainbow.sf.activities.receiver.NotificationPausePlayReceiver;
import android.view.View;

public class NotificationService extends Service
{
	public static String MENSAJE_KEY = "MENSAJE";
	String actionString;
	
	public NotificationService(){
		
	}
	@Override
	public IBinder onBind(Intent p1) {
		return null;
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		
		Intent i = new Intent(this,NotificationPausePlayReceiver.class);
		
	    actionString = ScreenFilterService.StateAction;
        int icon = ScreenFilterService.Icon;
		String content = ScreenFilterService.Description;
		
		PendingIntent pendingIntent = PendingIntent.getBroadcast(this,
																 1,i,PendingIntent.FLAG_UPDATE_CURRENT);

		
		NotificationCompat.Builder notify = new NotificationCompat.Builder(this);
		notify.setContentTitle("Screen Filter");
		notify.setSmallIcon(R.drawable.ic_play);
		notify.setContentText(content);
		notify.addAction(icon,actionString,pendingIntent);
		notify.setPriority(Notification.PRIORITY_HIGH);
		notify.setOngoing(true);
		
		NotificationManager nm = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
		int notifi = 0;

		nm.notify(notifi,notify.build());
		
		return super.onStartCommand(intent,flags,startId);
	}


	@Override
	public void onCreate() {
		super.onCreate();
		
		
		
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
	}
	
}
