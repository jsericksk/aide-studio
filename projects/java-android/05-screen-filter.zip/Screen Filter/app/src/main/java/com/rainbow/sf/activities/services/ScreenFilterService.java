package com.rainbow.sf.activities.services;
import android.app.Service;
import android.os.IBinder;
import android.content.Intent;
import android.view.View;
import com.rainbow.sf.activities.filters.FilterMemory;
import android.widget.LinearLayout;
import android.view.WindowManager;
import android.graphics.PixelFormat;
import android.content.Context;
import android.os.Build;

import com.rainbow.sf.R;
public class ScreenFilterService extends Service
{

	public static int STATE_ACTIVE = 0;
	public static int STATE_INACTIVE = 1;
	public static int STATE;
	
   public static String StateAction = "";
   public static String Description = "";
   public static int Icon;
	public FilterMemory fm;
	public View viewFilter;

	static{
		STATE = STATE_INACTIVE;
	}
	
	public ScreenFilterService(){
		
	}
	
	@Override
	public IBinder onBind(Intent i) {
		
		return null;
	}

	@Override
	public void onCreate() {
		super.onCreate();
		
		StateAction = "Pausar";
		Description = "Screen Filter En Ejecución";
		Icon = R.drawable.ic_pause;
		fm = new FilterMemory(this);
		viewFilter = new LinearLayout(this);
		viewFilter.setBackgroundColor(fm.getColor());
		
		WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
		WindowManager.LayoutParams.MATCH_PARENT,
		WindowManager.LayoutParams.MATCH_PARENT,
		WindowManager.LayoutParams.TYPE_SYSTEM_OVERLAY,280,
		PixelFormat.TRANSLUCENT
		);
		WindowManager wm = (WindowManager)getSystemService(Context.WINDOW_SERVICE);
		assert wm != null;
		wm.addView(viewFilter,lp);
		STATE = STATE_ACTIVE;
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		WindowManager wm = (WindowManager)getSystemService(Context.WINDOW_SERVICE);
		assert wm != null;
		wm.removeView(viewFilter);
		StateAction = "Reaundar";
		Description = "Screen Filter Detenido Pulsa Reanudar";
		Icon = R.drawable.ic_play;
		STATE = STATE_INACTIVE;
		
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		
		if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
			viewFilter.setBackgroundColor(fm.getColor());
			return START_STICKY;
		}else{
			viewFilter.setBackgroundColor(fm.getColor());
		return super.onStartCommand(intent,flags,startId);
		}
		}
	}
    
	

