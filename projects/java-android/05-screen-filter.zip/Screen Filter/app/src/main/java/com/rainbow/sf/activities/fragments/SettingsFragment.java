package com.rainbow.sf.activities.fragments;
import android.support.v7.preference.PreferenceFragmentCompat;
import android.os.Bundle;

import com.rainbow.sf.R;

public class SettingsFragment extends PreferenceFragmentCompat {

	
	@Override
	public void onCreatePreferences(Bundle p1, String p2) {
		setPreferencesFromResource(R.xml.settings_preferences,p2);
	}


}
