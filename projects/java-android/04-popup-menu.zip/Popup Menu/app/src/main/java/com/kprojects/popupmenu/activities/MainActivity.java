package com.kprojects.popupmenu.activities;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.PopupMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;
import com.kprojects.popupmenu.R;
import com.kprojects.popupmenu.activities.MainActivity;

public class MainActivity extends AppCompatActivity implements PopupMenu.OnMenuItemClickListener {
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
	}
	
	public void btShowPopupMenu(View view) {
		PopupMenu popup = new PopupMenu(this, view);
		popup.setOnMenuItemClickListener(this);
		popup.inflate(R.menu.popup_menu_main);
		popup.show();
	}
	
	@Override
	public boolean onMenuItemClick(MenuItem menuItem) {
		switch (menuItem.getItemId()) {
			case R.id.menu_rename:
				showToast("File renamed successfully!");
				break;
			case R.id.menu_delete:
				showToast("File deleted successfully!");
				break;
			case R.id.menu_help:
				showToast("Leon! Heeeelp! Leon!!!");
				break;
		}
		return false;
	}
	
	private void showToast(String str) {
		Toast.makeText(getApplicationContext(), str, Toast.LENGTH_SHORT).show();
	}
	
}
